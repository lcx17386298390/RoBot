from nonebot.default_config import *

SUPERUSERS = {2948065094}
COMMAND_START = {'', '/', '!', '／', '！'}
HOST = '0.0.0.0'
PORT = 53245
